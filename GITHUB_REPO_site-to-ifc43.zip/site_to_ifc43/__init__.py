# -*- coding: utf-8 -*-
def classFactory(iface):
    from .plugin import SiteToIfc43Plugin
    return SiteToIfc43Plugin(iface)
