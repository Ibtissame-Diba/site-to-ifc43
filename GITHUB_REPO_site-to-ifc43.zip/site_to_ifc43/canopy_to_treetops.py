# -*- coding: utf-8 -*-
"""
QGIS Processing algorithm:  Canopy nDOM raster -> tree TOPS (local maxima)
==========================================================================
Detects one point per crown apex by local-maximum filtering of a canopy
height model (nDOM = height above ground). Unlike the connected-components
tool, this finds individual treetops INSIDE closed canopy (a continuous
forest still has bumps at each crown apex), so dense stands get populated
instead of collapsing into one blob.

Method (pure numpy; no scipy required):
  1) read nDOM; mark valid cells (finite, not NoData)
  2) optional 3x3 mean smoothing to suppress spurious single-cell spikes
  3) window maximum: a cell is a candidate top if its height equals the max
     within a search window AND is >= the height threshold
  4) cluster touching candidate cells (a flat apex gives a small plateau) and
     emit ONE point per cluster at its highest cell; the search window sets
     the minimum spacing between detected trees
  5) (optional) keep only tops whose point is inside a clip mask polygon

Output point fields (named for the LAF1 tree rule in the exporter):
  tree_id, height (= nDOM at the apex), n_peak_cells
-> 'height' maps to bSD_Pset_Flora_Baum.Hoehe. Crown diameter is NOT produced
   here (local maxima locate stems, not crown extent); use the connected-
   components tool if you need a crown-area estimate for open-grown trees.

HONEST LIMITS: treetops are approximated as local CHM maxima. Bumpy/multi-stem
crowns may over-detect; broad flat crowns may merge. This is standard for
CHM-based detection and should be stated as a method limitation.
"""

from qgis.PyQt.QtCore import QCoreApplication, QVariant
from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterVectorLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterFeatureSink,
    QgsProcessingException,
    QgsFields,
    QgsField,
    QgsFeature,
    QgsGeometry,
    QgsPointXY,
    QgsWkbTypes,
    QgsCoordinateTransform,
    QgsProject,
)


def _shift2d(a, dr, dc, fill):
    """Shift array a by (dr, dc), filling exposed edges with `fill`."""
    import numpy as np
    out = np.full_like(a, fill)
    h, w = a.shape
    sr_src = slice(max(0, -dr), h - max(0, dr))
    sr_dst = slice(max(0, dr), h - max(0, -dr))
    sc_src = slice(max(0, -dc), w - max(0, dc))
    sc_dst = slice(max(0, dc), w - max(0, -dc))
    out[sr_dst, sc_dst] = a[sr_src, sc_src]
    return out


def _label8(mask):
    """8-connectivity components of a 2D boolean numpy array.
    Returns list of components, each a list of (row, col). scipy if present."""
    try:
        import numpy as np
        from scipy import ndimage
        lab, n = ndimage.label(mask, structure=np.ones((3, 3), dtype=int))
        comps = [[] for _ in range(n)]
        rr, cc = np.nonzero(lab)
        for r, c in zip(rr.tolist(), cc.tolist()):
            comps[lab[r, c] - 1].append((r, c))
        return comps
    except Exception:
        pass
    m = mask.tolist() if hasattr(mask, "tolist") else mask
    nrow = len(m); ncol = len(m[0]) if nrow else 0
    seen = [[False] * ncol for _ in range(nrow)]; comps = []
    for r in range(nrow):
        for c in range(ncol):
            if m[r][c] and not seen[r][c]:
                stack = [(r, c)]; seen[r][c] = True; cells = []
                while stack:
                    rr, cc = stack.pop(); cells.append((rr, cc))
                    for dr in (-1, 0, 1):
                        for dc in (-1, 0, 1):
                            if dr == 0 and dc == 0:
                                continue
                            nr, nc = rr + dr, cc + dc
                            if 0 <= nr < nrow and 0 <= nc < ncol and m[nr][nc] and not seen[nr][nc]:
                                seen[nr][nc] = True; stack.append((nr, nc))
                comps.append(cells)
    return comps


class CanopyToTreetops(QgsProcessingAlgorithm):
    NDOM = "NDOM"
    THRESH = "THRESH"
    WINDOW = "WINDOW"
    SMOOTH = "SMOOTH"
    MASK = "MASK"
    OUTPUT = "OUTPUT"

    def tr(self, s):
        return QCoreApplication.translate("CanopyToTreetops", s)

    def createInstance(self):
        return CanopyToTreetops()

    def name(self):
        return "canopytotreetops"

    def displayName(self):
        return self.tr("Canopy raster (nDOM) -> tree tops (local maxima)")

    def group(self):
        return self.tr("OpenBIM")

    def groupId(self):
        return "openbim"

    def shortHelpString(self):
        return self.tr(
            "Detect one point per crown apex from a canopy height raster (nDOM) by "
            "local-maximum filtering. Finds individual treetops inside closed canopy, "
            "so dense forest is populated rather than merged. The search window sets "
            "the minimum spacing between trees; the height threshold removes scrub. "
            "Output points carry 'height' (apex height) for the Vegetation-point slot "
            "of 'Site -> IFC 4.3'. Treetops are approximated as CHM local maxima."
        )

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.NDOM, self.tr("Canopy height raster nDOM (height above ground)")))
        self.addParameter(QgsProcessingParameterNumber(
            self.THRESH, self.tr("Tree height threshold (m)"),
            type=QgsProcessingParameterNumber.Double, defaultValue=5.0, minValue=0.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.WINDOW, self.tr("Search window / min tree spacing (m)"),
            type=QgsProcessingParameterNumber.Double, defaultValue=3.0, minValue=0.5))
        self.addParameter(QgsProcessingParameterBoolean(
            self.SMOOTH, self.tr("Light 3x3 smoothing (reduces spurious peaks)"),
            defaultValue=True))
        self.addParameter(QgsProcessingParameterVectorLayer(
            self.MASK, self.tr("Clip mask (optional polygon; keep tops inside it)"),
            types=[QgsProcessing.TypeVectorPolygon], optional=True))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT, self.tr("Tree tops"), QgsProcessing.TypeVectorPoint))

    def processAlgorithm(self, parameters, context, feedback):
        try:
            from osgeo import gdal
            import numpy as np
        except ImportError:
            raise QgsProcessingException("GDAL and numpy are required (both ship with QGIS).")

        raster = self.parameterAsRasterLayer(parameters, self.NDOM, context)
        thr = self.parameterAsDouble(parameters, self.THRESH, context)
        window_m = self.parameterAsDouble(parameters, self.WINDOW, context)
        smooth = self.parameterAsBool(parameters, self.SMOOTH, context)
        mask_layer = self.parameterAsVectorLayer(parameters, self.MASK, context)
        if raster is None:
            raise QgsProcessingException("Select a canopy raster.")

        src = raster.source().split("|")[0]
        ds = gdal.Open(src)
        if ds is None:
            raise QgsProcessingException("Could not open raster: %s" % src)
        band = ds.GetRasterBand(1)
        gt = ds.GetGeoTransform()
        nodata = band.GetNoDataValue()
        crs = raster.crs()
        px = abs(gt[1]); py = abs(gt[5])

        arr = band.ReadAsArray().astype("float64")
        valid = np.isfinite(arr)
        if nodata is not None:
            valid &= (arr != nodata)

        work = arr.copy()
        work[~valid] = np.nan
        if smooth:
            acc = np.zeros_like(work); cnt = np.zeros_like(work)
            base = np.where(valid, arr, 0.0)
            vmask = valid.astype("float64")
            for dr in (-1, 0, 1):
                for dc in (-1, 0, 1):
                    acc += _shift2d(base, dr, dc, 0.0)
                    cnt += _shift2d(vmask, dr, dc, 0.0)
            with np.errstate(invalid="ignore", divide="ignore"):
                work = np.where(cnt > 0, acc / cnt, np.nan)

        NEG = -1.0e18
        chm = np.where(valid & np.isfinite(work), work, NEG)
        rad = max(1, int(round(window_m / max(px, py))))
        locmax = chm.copy()
        for dr in range(-rad, rad + 1):
            for dc in range(-rad, rad + 1):
                if dr == 0 and dc == 0:
                    continue
                locmax = np.maximum(locmax, _shift2d(chm, dr, dc, NEG))
        peak = valid & (arr >= thr) & (chm >= locmax - 1e-6)
        feedback.pushInfo("Window radius %d cell(s) (~%.1f m); %d candidate peak cell(s)."
                          % (rad, rad * px, int(peak.sum())))

        comps = _label8(peak)

        mask_geom = None
        if mask_layer is not None:
            geoms = []; mct = None
            if mask_layer.crs().authid() != crs.authid():
                mct = QgsCoordinateTransform(mask_layer.crs(), crs, QgsProject.instance())
            for f in mask_layer.getFeatures():
                g = QgsGeometry(f.geometry())
                if mct is not None:
                    g.transform(mct)
                geoms.append(g)
            if geoms:
                mask_geom = QgsGeometry.unaryUnion(geoms)

        fields = QgsFields()
        fields.append(QgsField("tree_id", QVariant.Int))
        fields.append(QgsField("height", QVariant.Double))
        fields.append(QgsField("n_peak_cells", QVariant.Int))
        (sink, dest_id) = self.parameterAsSink(
            parameters, self.OUTPUT, context, fields, QgsWkbTypes.Point, crs)

        tree_id = 0
        for cells in comps:
            if feedback.isCanceled():
                break
            # apex = highest original-height cell in the cluster
            br, bc, bh = cells[0][0], cells[0][1], arr[cells[0][0], cells[0][1]]
            for (r, c) in cells:
                if arr[r, c] > bh:
                    br, bc, bh = r, c, arr[r, c]
            x = gt[0] + (bc + 0.5) * gt[1] + (br + 0.5) * gt[2]
            y = gt[3] + (bc + 0.5) * gt[4] + (br + 0.5) * gt[5]
            pt = QgsPointXY(x, y)
            if mask_geom is not None and not mask_geom.contains(QgsGeometry.fromPointXY(pt)):
                continue
            tree_id += 1
            f = QgsFeature(fields)
            f.setGeometry(QgsGeometry.fromPointXY(pt))
            f.setAttributes([tree_id, float(bh), int(len(cells))])
            sink.addFeature(f)

        feedback.pushInfo("Wrote %d tree top(s) (>= %.2f m, spacing ~%.1f m)."
                          % (tree_id, thr, rad * px))
        return {self.OUTPUT: dest_id}
