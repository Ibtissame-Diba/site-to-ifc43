# -*- coding: utf-8 -*-
from qgis.core import QgsApplication
from .provider import SiteToIfc43Provider


class SiteToIfc43Plugin:
    """Minimal processing-only plugin: registers one Processing provider."""

    def __init__(self, iface):
        self.iface = iface
        self.provider = None

    def initProcessing(self):
        # Guarded so it is safe whether QGIS calls this directly
        # (hasProcessingProvider=yes) or via initGui().
        if self.provider is None:
            self.provider = SiteToIfc43Provider()
            QgsApplication.processingRegistry().addProvider(self.provider)

    def initGui(self):
        self.initProcessing()

    def unload(self):
        if self.provider is not None:
            QgsApplication.processingRegistry().removeProvider(self.provider)
            self.provider = None
