# -*- coding: utf-8 -*-
"""
QGIS Processing script:  Site -> IFC 4.3  (LAFA-dictionary-driven)
==================================================================
Exports QGIS landscape layers to ONE georeferenced IFC 4.3 file in which the
IFC entity, the bSDD classification URI, and the Tier-2 property names are ALL
taken from the authoritative LAFA dictionary (BIM-Fachmodell Landschaft und
Freianlage, buildingSMART Deutschland, version 1.0, Preview) -- NOT guessed.

The dictionary is shipped as `lafa_dict.json` next to this file (64 classes,
each with its prescribed Related-IFC-entity, its class URI, and its full
property catalogue with property-set names and datatypes, fetched from the
bSDD API). Edit only the small mapping blocks below to assign your layers to a
LAFA class; everything else is derived from the dictionary.

KEY FACTS THE DICTIONARY ESTABLISHES (these were wrong in earlier versions):
  * The dictionary code is LAFA (not "LAF1"); URI base
    https://identifier.buildingsmart.org/uri/buildingsmart-de/LAFA/1.0
  * Flora and Fauna are OBSERVATION classes -> IfcSpatialZone / OCCUPANCY
    (a "Fund-/Beobachtungsstelle"), NOT IfcGeographicElement.
  * FFH-Lebensraumtyp, Schutzgebiet-objekt, Bezugsraum -> IfcSpatialZone/OCCUPANCY
  * Biotop, Habitat, Wirkzone, Quartier_Fauna -> IfcSpatialZone
  * Physical vegetation (a tree, a vegetation area) is Pflanze / Vegetationsflaeche
    -> IfcGeographicElement / VEGETATION
  * Boden_Schutzgut -> IfcGeotechnicalElement
  * The universal class carrier is Klasse_bSD in bSD_Pset_0_LA_Klassifikation.

SPATIAL COMPOSITION (validator rule SPS002): only spatial-structure facilities
may be AGGREGATED under IfcSite. So:
  * IfcSpatialZone (zones, species, LRT, Schutzgebiet, ...) -> REFERENCED
    (IfcRelReferencedInSpatialStructure)
  * IfcGeographicElement / IfcGeotechnicalElement / other physical IfcElement
    subtypes -> CONTAINED (IfcRelContainedInSpatialStructure)
  * IfcSpace / IfcFacility-type -> AGGREGATED (IfcRelAggregates)
  * IfcTask / IfcEvent / IfcProcedure are processes (no geometry/placement):
    created with properties + classification only.

CONSEQUENCE FOR REVIT: because the dictionary maps most biodiversity classes to
IfcSpatialZone, and Autodesk Revit's IFC link does not render IfcSpatialZone,
much of this data is invisible IN REVIT but fully present, valid and visible in
BIMvision / the buildingSMART validator / any IFC4.3-native viewer. That is a
dictionary-prescribed interoperability finding, not a defect in this export.

For EVERY feature, ALL attributes are preserved: fields that match a LAFA
property (by alias or by name) are written into the correct bSD_Pset_* with the
authoritative LAFA property name (Tier 2); every remaining field is kept in
ePset_Source_<layer> (Tier 3) so nothing is dropped.

INSTALL
  1) OSGeo4W Shell:   python -m pip install ifcopenshell   (then restart QGIS)
  2) Install this folder as a plugin (zip) via the Plugin Manager, OR add the
     script via Processing Toolbox. `lafa_dict.json` must sit beside this file.
"""

from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterMultipleLayers,
    QgsProcessingParameterString,
    QgsProcessingParameterNumber,
    QgsProcessingParameterCrs,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterFile,
    QgsProcessingParameterFileDestination,
    QgsProcessingException,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsProject,
    QgsGeometry,
    QgsPointXY,
    QgsWkbTypes,
    NULL,
)
import math
import os
import json
import re

import numpy as np


def _sanitize(s):
    return re.sub(r"[^0-9A-Za-z_]+", "_", str(s)).strip("_") or "Layer"


def _norm(s):
    """Normalise a field/property name for fuzzy matching."""
    return re.sub(r"[^0-9a-z]+", "", str(s).lower())


# ============================================================================
#  MAPPING CONFIG  --  EDIT THIS BLOCK to fit a project
# ============================================================================
# The LAFA *class* assigned to a layer. The IFC entity, the URI and the Tier-2
# property names then come from the dictionary automatically.
#
# LAYER_RULES: ordered (tokens, LAFA_class). The first rule whose any-token is a
# substring of the (lower-cased) layer name wins. Used for the zone/area and
# vegetation polygon inputs.
LAYER_RULES = [
    (("landschaftsschutz", "lsg"),                         "Schutzgebiet-objekt"),
    (("ffh gebiet", "ffh-gebiet", "ffhgebiet",
      "natura", "vogelschutz", "spa", "naturschutzgebiet",
      "nsg", "schutzgebiet"),                              "Schutzgebiet-objekt"),
    (("maehwiese", "mähwiese", "lrt", "lebensraum",
      "6510", "ffh-mahwiese", "fhh maehwiese"),            "FFH-Lebensraumtyp"),
    (("offenland", "wald biotop", "waldbiotop",
      "biotop", "bio-d"),                                  "Biotop"),
    (("habitat",),                                         "Habitat"),
    (("wirkzone", "wirkraum"),                             "Wirkzone"),
    (("bezugsraum",),                                      "Bezugsraum"),
    (("quartier",),                                        "Quartier_Fauna"),
    (("vegetationsfl", "gehoelz", "gehölz", "krone",
      "crown", "canopy"),                                  "Vegetationsflaeche"),
]

# Default class for the "vegetation polygons" input when no rule matches.
DEFAULT_VEG_POLY_CLASS = "Vegetationsflaeche"   # -> IfcGeographicElement/VEGETATION
# Default class for the "tree points" input.
DEFAULT_TREE_POINT_CLASS = "Pflanze"            # -> IfcGeographicElement/VEGETATION

# Species points: the LAFA class is chosen PER FEATURE from a kingdom field.
SPECIES_KINGDOM = {
    "animalia": "Fauna",   # -> IfcSpatialZone/OCCUPANCY
    "plantae":  "Flora",   # -> IfcSpatialZone/OCCUPANCY
}
DEFAULT_SPECIES_CLASS = "Flora"

# FIELD ALIASES: where a source field name does NOT match a LAFA property name
# (e.g. GBIF Darwin Core vs. the German LAFA property names). Keyed by LAFA
# class -> { source_field : exact_LAFA_property_name }. The property's set and
# datatype are looked up in the dictionary, so only the property NAME is needed.
FIELD_ALIASES = {
    "Fauna": {
        "scientificName":  "wissenschaftlicher_Name_der_kartierten_Art",
        "vernacularName":  "deutscher_Artenname_der_kartierten_Art",
        "individualCount": "Individuenzahl_Populationsgross_der_kartierten_Art",
        "basisOfRecord":   "Nachweisart",
        "year":            "Kartierungsjahr",
        "decimalLongitude": "X-Koordinate_des_Fundpunktes",
        "decimalLatitude":  "Y-Koordinate_des_Fundpunktes",
    },
    "Flora": {
        "scientificName":  "Name_botanisch",
        "vernacularName":  "deutscher_Artenname_der_kartierten_Art",
        "individualCount": "Individuenzahl_Populationsgross_der_kartierten_Art",
        "basisOfRecord":   "Nachweisart",
        "year":            "Kartierungsjahr",
    },
    "Pflanze": {
        "scientificName": "Name_botanisch",
        "height":   "Hoehe",   "hoehe": "Hoehe",
        "crown":    "Kronendurchmesser", "crown_dia": "Kronendurchmesser",
        "dbh":      "Stammdurchmesser",
    },
    "FFH-Lebensraumtyp": {
        "EU_CODE":   "EU-Code_Lebensraumtyp",
        "BEW_GES_ER": "Erhaltungszustand",
    },
}

# Predefined-type suffixes that may be glued onto an entity name in the
# dictionary's "Related IFC entities" string (e.g. IfcSpatialZoneOCCUPANCY).
_PREDEF_SUFFIXES = [
    "OCCUPANCY", "CONSTRUCTION", "VEGETATION", "WATER", "ROOFING", "CLADDING",
    "BALLASTBED", "TRENCH", "TOPSOILREMOVAL", "GUTTER", "GUARDRAIL",
    "RETAININGWALL", "MARINEDEFENCE", "PICTORAL", "SHELTER", "EROSIONPREVENTION",
]

# Entity-family routing (by BASE entity, predefined suffix stripped).
_ZONE_BASES = {"IfcSpatialZone"}
_PROCESS_BASES = {"IfcTask", "IfcEvent", "IfcProcedure"}
_AGGREGATE_BASES = {
    "IfcSpace", "IfcFacilityPartCommon", "IfcMarineFacility", "IfcFacility",
    "IfcBuilding", "IfcRoad", "IfcBridge", "IfcRailway", "IfcTunnel",
}
# everything else that is an IfcElement subtype -> CONTAINED.

# A few LAFA classes point at an ABSTRACT IFC entity that cannot be
# instantiated. Substitute the concrete subtype here. Verified against the
# IFC4X3 schema: IfcGeotechnicalElement is the only abstract base in LAFA 1.0;
# soil maps to a solid geotechnical stratum. (Grundwasser already resolves to
# the concrete IfcGeotechnicalStratum/WATER and needs no substitution.)
ABSTRACT_SUBSTITUTION = {
    # base_entity : (concrete_base, predefined_or_None)
    "IfcGeotechnicalElement": ("IfcGeotechnicalStratum", "SOLID"),
}

LAFA_DICT_URI = "https://identifier.buildingsmart.org/uri/buildingsmart-de/LAFA/1.0"
LAFA_DICT_NAME = "BIM-Fachmodell Landschaft und Freianlage"
LAFA_DICT_EDITION = "1.0"


def split_entity(s):
    """'IfcSpatialZoneOCCUPANCY' -> ('IfcSpatialZone', 'OCCUPANCY')."""
    if not s:
        return (None, None)
    for suf in _PREDEF_SUFFIXES:
        if s.endswith(suf) and len(s) > len(suf):
            return (s[:-len(suf)], suf)
    return (s, None)


def family_for(base):
    if base in _ZONE_BASES:
        return "zone"
    if base in _PROCESS_BASES:
        return "process"
    if base in _AGGREGATE_BASES:
        return "aggregate"
    return "element"


def layer_class(layer_name):
    ln = layer_name.lower()
    for tokens, cls in LAYER_RULES:
        for t in tokens:
            if t in ln:
                return cls
    return None


class SiteToIfc43Full(QgsProcessingAlgorithm):
    ZONE_POLY = "ZONE_POLY"
    VEG_POLY = "VEG_POLY"
    SPECIES_POINTS = "SPECIES_POINTS"
    VEG_POINTS = "VEG_POINTS"
    TARGET_CRS = "TARGET_CRS"
    DGM = "DGM"
    BASE_E = "BASE_E"
    BASE_N = "BASE_N"
    BASE_H = "BASE_H"
    POLY_NAME_FIELD = "POLY_NAME_FIELD"
    POINT_NAME_FIELD = "POINT_NAME_FIELD"
    POINT_KINGDOM_FIELD = "POINT_KINGDOM_FIELD"
    HEIGHT = "HEIGHT"
    MARKER = "MARKER"
    LAFA_DICT = "LAFA_DICT"
    OUTPUT = "OUTPUT"

    def tr(self, s):
        return QCoreApplication.translate("SiteToIfc43Full", s)

    def createInstance(self):
        return SiteToIfc43Full()

    def name(self):
        return "site_to_ifc43_lafa"

    def displayName(self):
        return self.tr("Site -> IFC 4.3 (LAFA dictionary-driven)")

    def group(self):
        return self.tr("OpenBIM")

    def groupId(self):
        return "openbim"

    def shortHelpString(self):
        return self.tr(
            "Export QGIS layers to ONE georeferenced IFC 4.3 file whose IFC "
            "entities, bSDD classification URIs and Tier-2 property names all "
            "come from the LAFA dictionary (lafa_dict.json shipped beside this "
            "script). Assign layers to a LAFA class in the LAYER_RULES / "
            "SPECIES_KINGDOM blocks at the top of the script; the entity and "
            "properties follow automatically. IfcSpatialZone is referenced, "
            "physical elements are contained (SPS002-clean). Most biodiversity "
            "classes are IfcSpatialZone and will NOT show in Revit but are valid "
            "and visible in BIMvision / the buildingSMART validator. Requires "
            "ifcopenshell in QGIS's Python."
        )

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterMultipleLayers(
            self.ZONE_POLY, self.tr("Zone / area polygon layers (FFH, LSG, Biotop, LRT, Habitat, Wirkzone ...)"),
            layerType=QgsProcessing.TypeVectorPolygon, optional=True))
        self.addParameter(QgsProcessingParameterMultipleLayers(
            self.VEG_POLY, self.tr("Vegetation polygon layers (-> Vegetationsflaeche / IfcGeographicElement)"),
            layerType=QgsProcessing.TypeVectorPolygon, optional=True))
        self.addParameter(QgsProcessingParameterMultipleLayers(
            self.SPECIES_POINTS, self.tr("Species point layers (-> Fauna/Flora by kingdom; IfcSpatialZone/OCCUPANCY)"),
            layerType=QgsProcessing.TypeVectorPoint, optional=True))
        self.addParameter(QgsProcessingParameterMultipleLayers(
            self.VEG_POINTS, self.tr("Tree point layers (-> Pflanze / IfcGeographicElement)"),
            layerType=QgsProcessing.TypeVectorPoint, optional=True))

        self.addParameter(QgsProcessingParameterCrs(
            self.TARGET_CRS, self.tr("Target CRS (all layers reprojected to this)"),
            defaultValue="EPSG:25832"))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.DGM, self.tr("DGM terrain raster (optional; gives every element its true Z)"),
            optional=True))
        self.addParameter(QgsProcessingParameterNumber(
            self.BASE_E, self.tr("Base point Easting (0 = auto shared origin)"),
            type=QgsProcessingParameterNumber.Double, defaultValue=0.0, optional=True))
        self.addParameter(QgsProcessingParameterNumber(
            self.BASE_N, self.tr("Base point Northing (0 = auto shared origin)"),
            type=QgsProcessingParameterNumber.Double, defaultValue=0.0, optional=True))
        self.addParameter(QgsProcessingParameterNumber(
            self.BASE_H, self.tr("Base height H (0 = auto = min sampled elevation)"),
            type=QgsProcessingParameterNumber.Double, defaultValue=0.0, optional=True))
        self.addParameter(QgsProcessingParameterString(
            self.POLY_NAME_FIELD, self.tr("Polygon name field (optional)"),
            defaultValue="", optional=True))
        self.addParameter(QgsProcessingParameterString(
            self.POINT_NAME_FIELD, self.tr("Point name field (optional)"),
            defaultValue="", optional=True))
        self.addParameter(QgsProcessingParameterString(
            self.POINT_KINGDOM_FIELD, self.tr("Species kingdom field (Animalia/Plantae)"),
            defaultValue="kingdom", optional=True))
        self.addParameter(QgsProcessingParameterNumber(
            self.HEIGHT, self.tr("Extrusion depth for polygons / zones (m)"),
            type=QgsProcessingParameterNumber.Double, defaultValue=1.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.MARKER, self.tr("Marker size for points (m)"),
            type=QgsProcessingParameterNumber.Double, defaultValue=2.0))
        self.addParameter(QgsProcessingParameterFile(
            self.LAFA_DICT, self.tr("LAFA dictionary JSON (blank = lafa_dict.json beside this script)"),
            optional=True, extension="json"))
        self.addParameter(QgsProcessingParameterFileDestination(
            self.OUTPUT, self.tr("Output IFC file"), fileFilter="IFC files (*.ifc)"))

    # ------------------------------------------------------------------
    def processAlgorithm(self, parameters, context, feedback):
        try:
            import ifcopenshell
            import ifcopenshell.api.root, ifcopenshell.api.context, ifcopenshell.api.profile
            import ifcopenshell.api.geometry, ifcopenshell.api.georeference
            import ifcopenshell.api.unit, ifcopenshell.api.pset, ifcopenshell.api.aggregate
            import ifcopenshell.api.spatial
            import ifcopenshell.api.classification
        except ImportError:
            raise QgsProcessingException(
                "IfcOpenShell is not installed in QGIS's Python.\n"
                "Open the OSGeo4W Shell and run:  python -m pip install ifcopenshell\n"
                "then restart QGIS.")

        # ---- load the LAFA dictionary -------------------------------------
        dict_path = (self.parameterAsString(parameters, self.LAFA_DICT, context) or "").strip()
        if not dict_path:
            dict_path = os.path.join(os.path.dirname(__file__), "lafa_dict.json")
        if not os.path.exists(dict_path):
            raise QgsProcessingException(
                "LAFA dictionary not found at: %s\nKeep lafa_dict.json beside the "
                "script or set the LAFA dictionary JSON parameter." % dict_path)
        with open(dict_path, "r", encoding="utf-8") as fh:
            LAFA = json.load(fh)
        feedback.pushInfo("LAFA dictionary loaded: %d classes from %s"
                          % (len(LAFA), os.path.basename(dict_path)))

        # per-class property index: norm(propname) -> (set, exact_name, datatype)
        prop_index = {}
        for cls, v in LAFA.items():
            idx = {}
            for p in v.get("properties", []):
                if p.get("name") and p.get("set"):
                    idx[_norm(p["name"])] = (p["set"], p["name"], p.get("dt"))
            prop_index[cls] = idx

        def class_info(cls):
            """-> (base_entity, predefined, family, uri) or None."""
            v = LAFA.get(cls)
            if not v:
                return None
            base, predef = split_entity(v.get("entity"))
            if base is None:
                base, predef = "IfcGeographicElement", None
            if base in ABSTRACT_SUBSTITUTION:
                sub_base, sub_predef = ABSTRACT_SUBSTITUTION[base]
                base = sub_base
                predef = predef or sub_predef
            return base, predef, family_for(base), v.get("uri")

        # ---- parameters ---------------------------------------------------
        zone_poly = self.parameterAsLayerList(parameters, self.ZONE_POLY, context) or []
        veg_poly = self.parameterAsLayerList(parameters, self.VEG_POLY, context) or []
        species_points = self.parameterAsLayerList(parameters, self.SPECIES_POINTS, context) or []
        veg_points = self.parameterAsLayerList(parameters, self.VEG_POINTS, context) or []
        target_crs = self.parameterAsCrs(parameters, self.TARGET_CRS, context)
        dgm = self.parameterAsRasterLayer(parameters, self.DGM, context)
        base_e = self.parameterAsDouble(parameters, self.BASE_E, context)
        base_n = self.parameterAsDouble(parameters, self.BASE_N, context)
        base_h = self.parameterAsDouble(parameters, self.BASE_H, context)
        poly_name_field = (self.parameterAsString(parameters, self.POLY_NAME_FIELD, context) or "").strip()
        point_name_field = (self.parameterAsString(parameters, self.POINT_NAME_FIELD, context) or "").strip()
        point_kingdom_field = (self.parameterAsString(parameters, self.POINT_KINGDOM_FIELD, context) or "").strip()
        height = self.parameterAsDouble(parameters, self.HEIGHT, context)
        marker = self.parameterAsDouble(parameters, self.MARKER, context)
        out_path = self.parameterAsFileOutput(parameters, self.OUTPUT, context)

        all_poly = zone_poly + veg_poly
        all_point = species_points + veg_points
        if not all_poly and not all_point:
            raise QgsProcessingException("Select at least one layer in any category.")
        if not target_crs.isValid():
            raise QgsProcessingException("Target CRS is not valid.")
        epsg = target_crs.authid() or "EPSG:25832"
        feedback.pushInfo("Target CRS: %s" % epsg)

        def transform_for(layer):
            if layer.crs().authid() == target_crs.authid():
                return None
            return QgsCoordinateTransform(layer.crs(), target_crs, QgsProject.instance())

        def reprojected_geom(feat, ct):
            g = QgsGeometry(feat.geometry())
            if g is None or g.isEmpty():
                return None
            if ct is not None and g.transform(ct) != 0:
                return None
            return g

        # ---- DGM terrain sampling ----------------------------------------
        dgm_provider = dgm.dataProvider() if dgm is not None else None
        dgm_ct = None
        if dgm is not None and dgm.crs().isValid() \
                and dgm.crs().authid() != target_crs.authid():
            dgm_ct = QgsCoordinateTransform(target_crs, dgm.crs(), QgsProject.instance())

        def sample_z(x, y):
            if dgm_provider is None:
                return None
            px, py = x, y
            if dgm_ct is not None:
                p = dgm_ct.transform(QgsPointXY(x, y))
                px, py = p.x(), p.y()
            val, ok = dgm_provider.sample(QgsPointXY(px, py), 1)
            if not ok or val is None:
                return None
            try:
                if math.isnan(val):
                    return None
            except TypeError:
                return None
            return float(val)

        def poly_parts(geom):
            if QgsWkbTypes.isMultiType(geom.wkbType()):
                polys = geom.asMultiPolygon()
            else:
                p = geom.asPolygon()
                polys = [p] if p else []
            for poly in polys:
                if not poly:
                    continue
                ext = [(pt.x(), pt.y()) for pt in poly[0]]
                holes = [[(pt.x(), pt.y()) for pt in r] for r in poly[1:]]
                yield ext, holes

        def point_coords(geom):
            if QgsWkbTypes.isMultiType(geom.wkbType()):
                return [(pt.x(), pt.y()) for pt in geom.asMultiPoint()]
            p = geom.asPoint()
            return [(p.x(), p.y())]

        # ---- shared origin -----------------------------------------------
        min_x = min_y = None
        for lyr in all_poly:
            ct = transform_for(lyr)
            for feat in lyr.getFeatures():
                g = reprojected_geom(feat, ct)
                if g is None:
                    continue
                for ext, _h in poly_parts(g):
                    for (x, y) in ext:
                        min_x = x if min_x is None else min(min_x, x)
                        min_y = y if min_y is None else min(min_y, y)
        for lyr in all_point:
            ct = transform_for(lyr)
            for feat in lyr.getFeatures():
                g = reprojected_geom(feat, ct)
                if g is None:
                    continue
                for (x, y) in point_coords(g):
                    min_x = x if min_x is None else min(min_x, x)
                    min_y = y if min_y is None else min(min_y, y)
        if min_x is None:
            raise QgsProcessingException("No geometry found in the selected layers.")
        if base_e > 0 and base_n > 0:
            ox, oy = float(base_e), float(base_n)
            feedback.pushInfo("Using explicit base point (E,N): %.1f, %.1f" % (ox, oy))
        else:
            ox = math.floor(min_x / 10.0) * 10.0
            oy = math.floor(min_y / 10.0) * 10.0
            feedback.pushInfo("Auto shared origin (E,N): %.1f, %.1f" % (ox, oy))

        # ---- base height --------------------------------------------------
        if dgm is None:
            oz = 0.0
            feedback.pushInfo("No DGM selected -> all elements flat at Z0.")
        elif base_h != 0.0:
            oz = float(base_h)
            feedback.pushInfo("Using explicit base height (H): %.2f" % oz)
        else:
            min_z = None
            for lyr in all_poly:
                ct = transform_for(lyr)
                for feat in lyr.getFeatures():
                    g = reprojected_geom(feat, ct)
                    if g is None:
                        continue
                    c = g.centroid().asPoint()
                    z = sample_z(c.x(), c.y())
                    if z is not None:
                        min_z = z if min_z is None else min(min_z, z)
            for lyr in all_point:
                ct = transform_for(lyr)
                for feat in lyr.getFeatures():
                    g = reprojected_geom(feat, ct)
                    if g is None:
                        continue
                    for (x, y) in point_coords(g):
                        z = sample_z(x, y)
                        if z is not None:
                            min_z = z if min_z is None else min(min_z, z)
            oz = math.floor(min_z) if min_z is not None else 0.0
            feedback.pushInfo("Auto base height (H): %.2f" % oz)

        # =================================================================
        #  IFC CORE
        # =================================================================
        def ifc_safe(v):
            if v is None or v == NULL:
                return None
            if isinstance(v, bool):
                return v
            if isinstance(v, int):
                return float(v) if (v > 2147483647 or v < -2147483648) else v
            if isinstance(v, (str, float)):
                return v
            return str(v)

        def coerce(dt, v):
            try:
                if dt == "Real":
                    return float(v)
                if dt == "Integer":
                    iv = int(float(v))
                    return float(iv) if (iv > 2147483647 or iv < -2147483648) else iv
                if dt == "Boolean":
                    if isinstance(v, bool):
                        return v
                    s = str(v).strip().lower()
                    if s in ("1", "true", "ja", "yes", "wahr", "x"):
                        return True
                    if s in ("0", "false", "nein", "no", "falsch"):
                        return False
                    return str(v)
            except Exception:
                return str(v)
            return str(v)  # String, Time

        def close_ring(pts):
            return pts + [pts[0]] if (pts and pts[0] != pts[-1]) else pts

        def make_profile(m, outer_pts, inner_list):
            outer_tmp = ifcopenshell.api.profile.add_arbitrary_profile(m, profile=outer_pts)
            if not inner_list:
                return outer_tmp
            outer_curve = outer_tmp.OuterCurve
            inner_curves = []
            for inner in inner_list:
                t = ifcopenshell.api.profile.add_arbitrary_profile(m, profile=inner)
                inner_curves.append(t.OuterCurve)
                m.remove(t)
            m.remove(outer_tmp)
            return m.create_entity("IfcArbitraryProfileDefWithVoids",
                                   ProfileType="AREA", OuterCurve=outer_curve, InnerCurves=inner_curves)

        m = ifcopenshell.file(schema="IFC4X3")
        project = ifcopenshell.api.root.create_entity(m, ifc_class="IfcProject", name="QGIS site export (LAFA)")
        ifcopenshell.api.unit.assign_unit(
            m, length={"is_metric": True, "raw": "METERS"},
            area={"is_metric": True, "raw": "METERS"},
            volume={"is_metric": True, "raw": "METERS"})
        model_ctx = ifcopenshell.api.context.add_context(m, context_type="Model")
        body = ifcopenshell.api.context.add_context(
            m, context_type="Model", context_identifier="Body",
            target_view="MODEL_VIEW", parent=model_ctx)
        site = ifcopenshell.api.root.create_entity(m, ifc_class="IfcSite", name="Site")
        ifcopenshell.api.geometry.edit_object_placement(m, product=site, matrix=np.eye(4))
        ifcopenshell.api.aggregate.assign_object(m, products=[site], relating_object=project)
        ifcopenshell.api.georeference.add_georeferencing(m)
        ifcopenshell.api.georeference.edit_georeferencing(
            m, projected_crs={"Name": epsg},
            coordinate_operation={"Eastings": float(ox), "Northings": float(oy), "OrthogonalHeight": float(oz)})

        clf = ifcopenshell.api.classification.add_classification(m, classification=LAFA_DICT_NAME)
        try:
            clf.Source = LAFA_DICT_URI
            clf.Edition = LAFA_DICT_EDITION
            clf.Location = LAFA_DICT_URI
        except Exception:
            pass

        name_candidates = ["MW_NAME", "name", "NAME", "Name", "FFH_NAME", "OBJEKT",
                           "BIOTOP", "GEB_NAME", "BEZEICHN", "NAME_DE"]
        counts = {"zone": 0, "element": 0, "aggregate": 0, "process": 0,
                  "z_set": 0, "z_miss": 0, "classified": 0, "t2": 0, "t3": 0,
                  "no_class": 0}
        unmatched_layers = set()

        # ---- classify + write props (dictionary-driven) ------------------
        def write_props(el, props, layer_name, cls, uri):
            buckets = {}
            if cls:
                ref = ifcopenshell.api.classification.add_reference(
                    m, products=[el], classification=clf,
                    identification=str(cls), name=str(cls))
                if uri:
                    try:
                        ref.Location = uri
                    except Exception:
                        pass
                buckets.setdefault("bSD_Pset_0_LA_Klassifikation", {})["Klasse_bSD"] = str(cls)
                counts["classified"] += 1
            idx = prop_index.get(cls, {})
            aliases = FIELD_ALIASES.get(cls, {})
            mapped = set()
            for src, val in props.items():
                if val in (None, ""):
                    continue
                target = None
                if src in aliases:
                    nm = _norm(aliases[src])
                    target = idx.get(nm)
                    if target is None:
                        # alias name not literally in dict index -> still honour it as String
                        target = (None, aliases[src], "String")
                else:
                    target = idx.get(_norm(src))
                if target is not None:
                    pset, pname, dt = target
                    if pset is None:
                        continue  # alias with unknown set -> fall through to Tier 3
                    buckets.setdefault(pset, {})[pname] = coerce(dt, val)
                    mapped.add(src)
                    counts["t2"] += 1
            rest = {k: v for k, v in props.items() if k not in mapped and v is not None}
            if rest:
                buckets["ePset_Source_" + _sanitize(layer_name)] = rest
                counts["t3"] += len(rest)
            for pset_name, data in buckets.items():
                if data:
                    ps = ifcopenshell.api.pset.add_pset(m, product=el, name=pset_name)
                    ifcopenshell.api.pset.edit_pset(m, pset=ps, properties=data)

        # Batched containment relations: one IfcRelContainedInSpatialStructure
        # for ALL spatial zones, one for ALL physical elements. Zones go via a
        # manually-built relation (IfcOpenShell's spatial.assign_container helper
        # rejects IfcSpatialZone because the helper expects the IfcElement-only
        # inverse `ContainedInStructure`; the schema itself accepts any IfcProduct
        # in `RelatedElements`, and the buildingSMART validator only forbids
        # aggregation of non-facility subtypes under IfcSite via SPS002, not
        # containment).
        import ifcopenshell.guid as _guid
        _zone_rel = m.create_entity(
            "IfcRelContainedInSpatialStructure",
            GlobalId=_guid.new(), OwnerHistory=None,
            Name="Spatial zones contained in site",
            Description=None,
            RelatedElements=[], RelatingStructure=site)

        def attach_spatial(el, fam):
            if fam == "zone":
                # Manually append to the batched relation -- bypasses the helper.
                cur = list(_zone_rel.RelatedElements or [])
                cur.append(el)
                _zone_rel.RelatedElements = cur
            elif fam == "aggregate":
                ifcopenshell.api.aggregate.assign_object(m, products=[el], relating_object=site)
            elif fam == "element":
                ifcopenshell.api.spatial.assign_container(m, products=[el], relating_structure=site)
            # 'process' -> no spatial relation

        def create_entity(base, predef, name):
            try:
                if predef:
                    return ifcopenshell.api.root.create_entity(
                        m, ifc_class=base, predefined_type=predef, name=name)
                return ifcopenshell.api.root.create_entity(m, ifc_class=base, name=name)
            except Exception:
                # fall back: create without predefined type, mark USERDEFINED if possible
                el = ifcopenshell.api.root.create_entity(m, ifc_class=base, name=name)
                try:
                    el.PredefinedType = "USERDEFINED"
                    el.ObjectType = predef or ""
                except Exception:
                    pass
                return el

        def poly_name(props, pset_name, fid):
            if poly_name_field and props.get(poly_name_field) not in (None, ""):
                return str(props[poly_name_field])
            for nf in name_candidates:
                if nf in props and props[nf] not in (None, ""):
                    return str(props[nf])
            return "%s_%s" % (pset_name, fid)

        # ---- polygon processor -------------------------------------------
        def process_polygons(layers, default_class):
            for lyr in layers:
                if feedback.isCanceled():
                    break
                ct = transform_for(lyr)
                lname = lyr.name()
                pset_name = _sanitize(lname)
                cls = layer_class(lname) or default_class
                ci = class_info(cls) if cls else None
                if ci is None:
                    unmatched_layers.add(lname)
                    base, predef, fam, uri = "IfcGeographicElement", None, "element", None
                    cls = None
                else:
                    base, predef, fam, uri = ci
                feedback.pushInfo("Polygon layer '%s' (%s) -> class %s -> %s%s [%s]"
                                  % (lname, lyr.crs().authid(), cls or "(none)", base,
                                     "/" + predef if predef else "", fam))
                for feat in lyr.getFeatures():
                    g = reprojected_geom(feat, ct)
                    if g is None:
                        continue
                    props = {f.name(): ifc_safe(feat[f.name()]) for f in lyr.fields()}
                    parts = list(poly_parts(g))
                    multipart = len(parts) > 1
                    cpt = g.centroid().asPoint()
                    zc = sample_z(cpt.x(), cpt.y())
                    z_rel = (zc - oz) if zc is not None else 0.0
                    if dgm is not None:
                        counts["z_set" if zc is not None else "z_miss"] += 1
                    for pi, (ext, holes) in enumerate(parts, start=1):
                        nm = poly_name(props, pset_name, feat.id())
                        if multipart:
                            nm += "_part%d" % pi
                        el = create_entity(base, predef, nm)
                        extL = close_ring([(x - ox, y - oy) for (x, y) in ext])
                        holesL = [close_ring([(x - ox, y - oy) for (x, y) in r]) for r in holes]
                        try:
                            profile = make_profile(m, extL, holesL)
                            rep = ifcopenshell.api.geometry.add_profile_representation(
                                m, context=body, profile=profile, depth=float(height))
                            ifcopenshell.api.geometry.assign_representation(m, product=el, representation=rep)
                        except Exception as e:
                            feedback.pushInfo("  (geometry skipped for %s: %s)" % (base, e))
                        pmat = np.eye(4); pmat[2, 3] = z_rel
                        ifcopenshell.api.geometry.edit_object_placement(m, product=el, matrix=pmat)
                        attach_spatial(el, fam)
                        write_props(el, props, lname, cls, uri)
                        counts[fam] += 1

        # ---- point processor ---------------------------------------------
        def process_points(layers, mode):
            for lyr in layers:
                if feedback.isCanceled():
                    break
                ct = transform_for(lyr)
                lname = lyr.name()
                pset_name = _sanitize(lname)
                feedback.pushInfo("Point layer '%s' (%s) -> %s" % (lname, lyr.crs().authid(), mode))
                for feat in lyr.getFeatures():
                    g = reprojected_geom(feat, ct)
                    if g is None:
                        continue
                    props = {f.name(): ifc_safe(feat[f.name()]) for f in lyr.fields()}
                    if mode == "species":
                        kingdom = props.get(point_kingdom_field) if point_kingdom_field else None
                        k = (str(kingdom).strip().lower() if kingdom not in (None, "", NULL) else "")
                        cls = SPECIES_KINGDOM.get(k, DEFAULT_SPECIES_CLASS)
                    else:
                        cls = DEFAULT_TREE_POINT_CLASS
                    ci = class_info(cls)
                    if ci is None:
                        base, predef, fam, uri = "IfcGeographicElement", "VEGETATION", "element", None
                        cls = None
                    else:
                        base, predef, fam, uri = ci
                    for (x, y) in point_coords(g):
                        z = sample_z(x, y)
                        z_rel = (z - oz) if z is not None else 0.0
                        if dgm is not None:
                            counts["z_set" if z is not None else "z_miss"] += 1
                        if point_name_field and props.get(point_name_field) not in (None, ""):
                            nm = str(props[point_name_field])
                        else:
                            nm = "%s_%s" % (pset_name, feat.id())
                        el = create_entity(base, predef, nm)
                        h = marker / 2.0
                        ext = close_ring([(x - ox - h, y - oy - h), (x - ox + h, y - oy - h),
                                          (x - ox + h, y - oy + h), (x - ox - h, y - oy + h)])
                        try:
                            profile = make_profile(m, ext, [])
                            rep = ifcopenshell.api.geometry.add_profile_representation(
                                m, context=body, profile=profile, depth=float(marker))
                            ifcopenshell.api.geometry.assign_representation(m, product=el, representation=rep)
                        except Exception as e:
                            feedback.pushInfo("  (geometry skipped for %s: %s)" % (base, e))
                        mat = np.eye(4); mat[2, 3] = z_rel
                        ifcopenshell.api.geometry.edit_object_placement(m, product=el, matrix=mat)
                        attach_spatial(el, fam)
                        write_props(el, props, lname, cls, uri)
                        counts[fam] += 1

        process_polygons(zone_poly, None)
        process_polygons(veg_poly, DEFAULT_VEG_POLY_CLASS)
        process_points(species_points, "species")
        process_points(veg_points, "tree")

        # Discard the batched zone relation if no zones were attached (schema
        # requires SET[1:?] for RelatedElements).
        if not _zone_rel.RelatedElements:
            m.remove(_zone_rel)

        m.write(out_path)
        feedback.pushInfo(
            "Wrote: %d zone(s) referenced, %d element(s) contained, %d aggregated, "
            "%d process object(s) -> %s"
            % (counts["zone"], counts["element"], counts["aggregate"], counts["process"], out_path))
        feedback.pushInfo(
            "Classified: %d | Tier-2 props: %d | Tier-3 preserved: %d"
            % (counts["classified"], counts["t2"], counts["t3"]))
        if dgm is not None:
            feedback.pushInfo("Terrain Z set: %d | missing: %d" % (counts["z_set"], counts["z_miss"]))
        if unmatched_layers:
            feedback.pushInfo("WARNING: no LAYER_RULES match (left unclassified): %s"
                              % ", ".join(sorted(unmatched_layers)))
        return {self.OUTPUT: out_path}
