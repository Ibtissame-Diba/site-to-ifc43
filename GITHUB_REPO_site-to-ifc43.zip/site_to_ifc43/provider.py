# -*- coding: utf-8 -*-
from qgis.core import QgsProcessingProvider
from .site_to_ifc43_algorithm import SiteToIfc43Full
from .canopy_to_trees import CanopyToTrees
from .canopy_to_treetops import CanopyToTreetops


class SiteToIfc43Provider(QgsProcessingProvider):

    def loadAlgorithms(self):
        self.addAlgorithm(SiteToIfc43Full())
        self.addAlgorithm(CanopyToTrees())
        self.addAlgorithm(CanopyToTreetops())

    def id(self):
        return "siteifc43"

    def name(self):
        return "Site to IFC 4.3"

    def longName(self):
        return "Site to IFC 4.3"
