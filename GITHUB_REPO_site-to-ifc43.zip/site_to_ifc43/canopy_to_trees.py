# -*- coding: utf-8 -*-
"""
QGIS Processing algorithm:  Canopy nDOM raster -> tree points
=============================================================
Turns a normalised surface / canopy-height raster (nDOM = height above
ground) into ONE point per tree, ready for the Vegetation-point slot of the
"Site -> IFC 4.3" exporter.

Steps (all in one run):
  1) threshold the raster: cells >= height threshold are canopy
  2) group connected canopy cells into crowns (8-connectivity)
  3) drop crowns below a minimum area (removes single-pixel noise)
  4) per crown: centroid point, max height, mean height, area, equivalent
     crown diameter (2*sqrt(area/pi)), cell count
  5) (optional) keep only crowns whose centroid is inside a clip mask polygon

Output point fields (named to match the LAF1 tree rule in the exporter):
  tree_id, height (= max), height_mean, crown_dia, area_m2, n_cells
-> 'height' maps to bSD_Pset_Flora_Baum.Hoehe and 'crown_dia' to
   Kronendurchmesser; the rest is preserved (Tier 3).

Uses GDAL (raster read) + numpy; uses scipy.ndimage.label when available for
speed, otherwise a built-in flood-fill (same result, slower on large tiles).
"""

from qgis.PyQt.QtCore import QCoreApplication, QVariant
from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterVectorLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterFeatureSink,
    QgsProcessingException,
    QgsFields,
    QgsField,
    QgsFeature,
    QgsGeometry,
    QgsPointXY,
    QgsWkbTypes,
    QgsCoordinateTransform,
    QgsProject,
)
import math


def label_components(canopy):
    """8-connectivity connected components on a 2D boolean list-of-lists or
    numpy array. Returns list of components, each a list of (row, col).
    Tries scipy first; falls back to an iterative flood fill."""
    try:
        import numpy as np
        from scipy import ndimage
        arr = np.asarray(canopy, dtype=bool)
        structure = np.ones((3, 3), dtype=int)          # 8-connectivity
        labels, nlab = ndimage.label(arr, structure=structure)
        comps = [[] for _ in range(nlab)]
        rows, cols = np.nonzero(labels)
        for r, c in zip(rows.tolist(), cols.tolist()):
            comps[labels[r, c] - 1].append((r, c))
        return comps
    except Exception:
        pass
    # ---- fallback: iterative flood fill -------------------------------
    nrow = len(canopy)
    ncol = len(canopy[0]) if nrow else 0
    seen = [[False] * ncol for _ in range(nrow)]
    comps = []
    for r in range(nrow):
        row = canopy[r]
        for c in range(ncol):
            if row[c] and not seen[r][c]:
                stack = [(r, c)]
                seen[r][c] = True
                cells = []
                while stack:
                    rr, cc = stack.pop()
                    cells.append((rr, cc))
                    for dr in (-1, 0, 1):
                        for dc in (-1, 0, 1):
                            if dr == 0 and dc == 0:
                                continue
                            nr, nc = rr + dr, cc + dc
                            if 0 <= nr < nrow and 0 <= nc < ncol \
                                    and canopy[nr][nc] and not seen[nr][nc]:
                                seen[nr][nc] = True
                                stack.append((nr, nc))
                comps.append(cells)
    return comps


class CanopyToTrees(QgsProcessingAlgorithm):
    NDOM = "NDOM"
    THRESH = "THRESH"
    MIN_AREA = "MIN_AREA"
    MASK = "MASK"
    OUTPUT = "OUTPUT"

    def tr(self, s):
        return QCoreApplication.translate("CanopyToTrees", s)

    def createInstance(self):
        return CanopyToTrees()

    def name(self):
        return "canopytotrees"

    def displayName(self):
        return self.tr("Canopy raster (nDOM) -> tree points")

    def group(self):
        return self.tr("OpenBIM")

    def groupId(self):
        return "openbim"

    def shortHelpString(self):
        return self.tr(
            "Convert a canopy-height raster (nDOM, height above ground) into one "
            "point per tree: threshold by height, group connected canopy cells "
            "(8-connectivity), drop crowns below a minimum area, and output points "
            "carrying height (max), height_mean, crown_dia and area. Feed the result "
            "into the Vegetation-point slot of 'Site -> IFC 4.3'."
        )

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.NDOM, self.tr("Canopy height raster nDOM (height above ground)")))
        self.addParameter(QgsProcessingParameterNumber(
            self.THRESH, self.tr("Tree height threshold (m)"),
            type=QgsProcessingParameterNumber.Double, defaultValue=5.0, minValue=0.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.MIN_AREA, self.tr("Minimum crown area (m^2)"),
            type=QgsProcessingParameterNumber.Double, defaultValue=4.0, minValue=0.0))
        self.addParameter(QgsProcessingParameterVectorLayer(
            self.MASK, self.tr("Clip mask (optional polygon; keep crowns inside it)"),
            types=[QgsProcessing.TypeVectorPolygon], optional=True))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT, self.tr("Tree points"), QgsProcessing.TypeVectorPoint))

    def processAlgorithm(self, parameters, context, feedback):
        try:
            from osgeo import gdal
        except ImportError:
            raise QgsProcessingException("GDAL Python bindings not available in QGIS.")

        raster = self.parameterAsRasterLayer(parameters, self.NDOM, context)
        thr = self.parameterAsDouble(parameters, self.THRESH, context)
        min_area = self.parameterAsDouble(parameters, self.MIN_AREA, context)
        mask_layer = self.parameterAsVectorLayer(parameters, self.MASK, context)
        if raster is None:
            raise QgsProcessingException("Select a canopy raster.")

        src = raster.source().split("|")[0]
        ds = gdal.Open(src)
        if ds is None:
            raise QgsProcessingException("Could not open raster: %s" % src)
        band = ds.GetRasterBand(1)
        gt = ds.GetGeoTransform()
        nodata = band.GetNoDataValue()
        crs = raster.crs()
        px = abs(gt[1]); py = abs(gt[5])
        pix_area = px * py
        feedback.pushInfo("Raster %dx%d, pixel %.3g x %.3g m, threshold %.2f m, min area %.2f m^2"
                          % (ds.RasterXSize, ds.RasterYSize, px, py, thr, min_area))

        # ---- read + threshold -----------------------------------------
        try:
            import numpy as np
            arr = band.ReadAsArray().astype("float64")
            canopy = (arr >= thr) & np.isfinite(arr)
            if nodata is not None:
                canopy &= (arr != nodata)
            heights_of = lambda cells: [float(arr[r, c]) for (r, c) in cells]
            use_np = True
        except Exception:
            raw = band.ReadAsArray()
            arr = [[float(v) for v in row] for row in raw]
            canopy = [[(v >= thr and (nodata is None or v != nodata)) for v in row] for row in arr]
            heights_of = lambda cells: [arr[r][c] for (r, c) in cells]
            use_np = False

        comps = label_components(canopy)
        feedback.pushInfo("Found %d connected canopy blob(s); filtering by area..." % len(comps))

        # ---- optional clip mask (unioned, reprojected to raster CRS) ---
        mask_geom = None
        if mask_layer is not None:
            geoms = []
            mct = None
            if mask_layer.crs().authid() != crs.authid():
                mct = QgsCoordinateTransform(mask_layer.crs(), crs, QgsProject.instance())
            for f in mask_layer.getFeatures():
                g = QgsGeometry(f.geometry())
                if mct is not None:
                    g.transform(mct)
                geoms.append(g)
            if geoms:
                mask_geom = QgsGeometry.unaryUnion(geoms)

        # ---- output fields --------------------------------------------
        fields = QgsFields()
        fields.append(QgsField("tree_id", QVariant.Int))
        fields.append(QgsField("height", QVariant.Double))
        fields.append(QgsField("height_mean", QVariant.Double))
        fields.append(QgsField("crown_dia", QVariant.Double))
        fields.append(QgsField("area_m2", QVariant.Double))
        fields.append(QgsField("n_cells", QVariant.Int))
        (sink, dest_id) = self.parameterAsSink(
            parameters, self.OUTPUT, context, fields, QgsWkbTypes.Point, crs)

        tree_id = 0
        kept = 0
        total = max(len(comps), 1)
        for i, cells in enumerate(comps):
            if feedback.isCanceled():
                break
            feedback.setProgress(int(100 * i / total))
            n = len(cells)
            area = n * pix_area
            if area < min_area:
                continue
            hs = heights_of(cells)
            hmax = max(hs)
            hmean = sum(hs) / n
            mr = sum(r for r, _ in cells) / n
            mc = sum(c for _, c in cells) / n
            x = gt[0] + (mc + 0.5) * gt[1] + (mr + 0.5) * gt[2]
            y = gt[3] + (mc + 0.5) * gt[4] + (mr + 0.5) * gt[5]
            pt = QgsPointXY(x, y)
            if mask_geom is not None and not mask_geom.contains(QgsGeometry.fromPointXY(pt)):
                continue
            crown = 2.0 * math.sqrt(area / math.pi)
            tree_id += 1
            kept += 1
            f = QgsFeature(fields)
            f.setGeometry(QgsGeometry.fromPointXY(pt))
            f.setAttributes([tree_id, float(hmax), float(hmean),
                             float(crown), float(area), int(n)])
            sink.addFeature(f)

        feedback.pushInfo("Wrote %d tree point(s) (>= %.2f m, >= %.2f m^2)." % (kept, thr, min_area))
        return {self.OUTPUT: dest_id}
